<?php
/**
 * @package PHREEZEFB
 *
 * APPLICATION-WIDE CONFIGURATION SETTINGS
 *
 * This file contains application-wide configuration settings.  The settings
 * here will be the same regardless of the machine on which the app is running.
 *
 * This configuration should be added to version control.
 *
 * No settings should be added to this file that would need to be changed
 * on a per-machine basic (ie local, staging or production).  Any
 * machine-specific settings should be added to _machine_config.php
 */

/**
 * APPLICATION ROOT DIRECTORY
 * If the application doesn't detect this correctly then it can be set explicitly
 */
GlobalConfig::$APP_ROOT = realpath("./");

/**
 * INCLUDE PATH
 * Adjust the include path as necessary so PHP can locate required libraries
 */
set_include_path(
		GlobalConfig::$APP_ROOT . '/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/libs/phreeze/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/../phreeze/libs' . PATH_SEPARATOR .
		get_include_path()
);

// this is required here because we save it in the session and so it needs
// to be loaded before we access the session
require_once 'Model/User.php';

/**
 * RENDER ENGINE
 * You can use any template system that implements
 * IRenderEngine for the view layer.  Phreeze provides pre-built
 * implementations for Smarty, Savant and plain PHP.
 */
require_once 'verysimple/Phreeze/SavantRenderEngine.php';
GlobalConfig::$TEMPLATE_ENGINE = 'SavantRenderEngine';
GlobalConfig::$TEMPLATE_PATH = GlobalConfig::$APP_ROOT . '/templates/';

/**
 * ROUTE MAP
 * The route map connects URLs to Controller+Method and additionally maps the
 * wildcards to a named parameter so that they are accessible inside the
 * Controller without having to parse the URL for parameters such as IDs
 */
GlobalConfig::$ROUTE_MAP = array(

	// default controller when no route specified
	'GET:' => array('route' => 'Default.Home'),
		
	// when facebook shows the app in the canvas it makes a post instead of a get request
	'POST:' => array('route' => 'Default.Home'),
		
	// these are the endpoints used by the facebook login api
	'POST:api/facebooklogin' => array('route' => 'Auth.FacebookLogin'),
	'GET:api/facebooklogin' => array('route' => 'Auth.FacebookLogin'),
	'GET:api/currentuser' => array('route' => 'Auth.Read'),
	'GET:api/currentuser/(:num)' => array('route' => 'Auth.Read', 'params' => array('id' => 2)),
	'PUT:api/currentuser/(:num)' => array('route' => 'Auth.Update', 'params' => array('id' => 2)),
		
	// Nonce
	'GET:nonces' => array('route' => 'Nonce.ListView'),
	'GET:nonce/(:num)' => array('route' => 'Nonce.SingleView', 'params' => array('id' => 1)),
	'GET:api/nonces' => array('route' => 'Nonce.Query'),
	'POST:api/nonce' => array('route' => 'Nonce.Create'),
	'GET:api/nonce/(:num)' => array('route' => 'Nonce.Read', 'params' => array('id' => 2)),
	'PUT:api/nonce/(:num)' => array('route' => 'Nonce.Update', 'params' => array('id' => 2)),
	'DELETE:api/nonce/(:num)' => array('route' => 'Nonce.Delete', 'params' => array('id' => 2)),
		
	// User
	'GET:users' => array('route' => 'User.ListView'),
	'GET:user/(:num)' => array('route' => 'User.SingleView', 'params' => array('id' => 1)),
	'GET:api/users' => array('route' => 'User.Query'),
	'POST:api/user' => array('route' => 'User.Create'),
	'GET:api/user/(:num)' => array('route' => 'User.Read', 'params' => array('id' => 2)),
	'PUT:api/user/(:num)' => array('route' => 'User.Update', 'params' => array('id' => 2)),
	'DELETE:api/user/(:num)' => array('route' => 'User.Delete', 'params' => array('id' => 2)),

	// catch any broken API urls
	'GET:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'PUT:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'POST:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'DELETE:api/(:any)' => array('route' => 'Default.ErrorApi404')
);

/**
 * FETCHING STRATEGY
 * You may uncomment any of the lines below to specify always eager fetching.
 * Alternatively, you can copy/paste to a specific page for one-time eager fetching
 * If you paste into a controller method, replace $G_PHREEZER with $this->Phreezer
 */
?>