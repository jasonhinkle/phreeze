<?php
	$this->assign('title','PHREEZEFB | Users');
	$this->assign('nav','users');

	$this->display('_Header.tpl.php');
?>

<script type="text/javascript">
	$LAB.script("scripts/app/users.js").wait(function(){
		page.init();
	});
</script>

<div class="container">

<h1>
	<i class="icon-th-list"></i> Users
	<span id=loader class="loader progress progress-striped active"><span class="bar"></span></span>
</h1>

	<!-- underscore template for the collection -->
	<script type="text/template" id="userCollectionTemplate">
		<table class="collection table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Status</th>
				<th>Username</th>
				<th>Facebook Id</th>
				<th>Facebook Url</th>
<!-- UNCOMMENT TO SHOW ADDITIONAL COLUMNS
				<th>Email</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Gender</th>
				<th>Locale</th>
				<th>Timezone</th>
-->
			</tr>
		</thead>
		<tbody>
		<% items.each(function(item) { %>
			<tr id="<%= _.escape(item.get('id')) %>">
				<td><%= _.escape(item.get('id') || '') %></td>
				<td><%= _.escape(item.get('status') || '') %></td>
				<td><%= _.escape(item.get('username') || '') %></td>
				<td><%= _.escape(item.get('facebookId') || '') %></td>
				<td><%= _.escape(item.get('facebookUrl') || '') %></td>
<!-- UNCOMMENT TO SHOW ADDITIONAL COLUMNS
				<td><%= _.escape(item.get('email') || '') %></td>
				<td><%= _.escape(item.get('firstName') || '') %></td>
				<td><%= _.escape(item.get('lastName') || '') %></td>
				<td><%= _.escape(item.get('gender') || '') %></td>
				<td><%= _.escape(item.get('locale') || '') %></td>
				<td><%= _.escape(item.get('timezone') || '') %></td>
-->
			</tr>
		<% }); %>
		</tbody>
		</table>

		<%=  view.getPaginationHtml(page) %>
	</script>

	<!-- underscore template for the model -->
	<script type="text/template" id="userModelTemplate">
		<form class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div id="idInputContainer" class="control-group">
					<label class="control-label" for="id">Id</label>
					<div class="controls inline-inputs">
						<span class="input-xlarge uneditable-input" id="id"><%= _.escape(item.get('id') || '') %></span>
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="statusInputContainer" class="control-group">
					<label class="control-label" for="status">Status</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="status" placeholder="Status" value="<%= _.escape(item.get('status') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="usernameInputContainer" class="control-group">
					<label class="control-label" for="username">Username</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="username" placeholder="Username" value="<%= _.escape(item.get('username') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="facebookIdInputContainer" class="control-group">
					<label class="control-label" for="facebookId">Facebook Id</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="facebookId" placeholder="Facebook Id" value="<%= _.escape(item.get('facebookId') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="facebookUrlInputContainer" class="control-group">
					<label class="control-label" for="facebookUrl">Facebook Url</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="facebookUrl" placeholder="Facebook Url" value="<%= _.escape(item.get('facebookUrl') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="emailInputContainer" class="control-group">
					<label class="control-label" for="email">Email</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="email" placeholder="Email" value="<%= _.escape(item.get('email') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="firstNameInputContainer" class="control-group">
					<label class="control-label" for="firstName">First Name</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="firstName" placeholder="First Name" value="<%= _.escape(item.get('firstName') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="lastNameInputContainer" class="control-group">
					<label class="control-label" for="lastName">Last Name</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="lastName" placeholder="Last Name" value="<%= _.escape(item.get('lastName') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="genderInputContainer" class="control-group">
					<label class="control-label" for="gender">Gender</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="gender" placeholder="Gender" value="<%= _.escape(item.get('gender') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="localeInputContainer" class="control-group">
					<label class="control-label" for="locale">Locale</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="locale" placeholder="Locale" value="<%= _.escape(item.get('locale') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="timezoneInputContainer" class="control-group">
					<label class="control-label" for="timezone">Timezone</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="timezone" placeholder="Timezone" value="<%= _.escape(item.get('timezone') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
			</fieldset>
		</form>

		<!-- delete button is is a separate form to prevent enter key from triggering a delete -->
		<form id="deleteUserButtonContainer" class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div class="control-group">
					<label class="control-label"></label>
					<div class="controls">
						<button id="deleteUserButton" class="btn btn-mini btn-danger"><i class="icon-trash icon-white"></i> Delete User</button>
						<span id="confirmDeleteUserContainer" class="hide">
							<button id="cancelDeleteUserButton" class="btn btn-mini">Cancel</button>
							<button id="confirmDeleteUserButton" class="btn btn-mini btn-danger">Confirm</button>
						</span>
					</div>
				</div>
			</fieldset>
		</form>
	</script>

	<!-- modal edit dialog -->
	<div class="modal hide fade" id="userDetailDialog">
		<div class="modal-header">
			<a class="close" data-dismiss="modal">&times;</a>
			<h3>
				<i class="icon-edit"></i> Edit User
				<span id="modelLoader" class="loader progress progress-striped active"><span class="bar"></span></span>
			</h3>
		</div>
		<div class="modal-body">
			<div id="modelAlert"></div>
			<div id="userModelContainer"></div>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" >Cancel</button>
			<button id="saveUserButton" class="btn btn-primary">Save Changes</button>
		</div>
	</div>

	<div id="collectionAlert"></div>

	<div id="userCollectionContainer" class="collectionContainer">
	</div>

	<p id="newButtonContainer" class="buttonContainer">
		<button id="newUserButton" class="btn btn-primary">Add User</button>
	</p>

	<!-- footer -->
	<hr>

	<footer>
		<p>&copy; <?php echo date('Y'); ?> PHREEZEFB</p>
	</footer>

</div> <!-- /container -->

<?php
	$this->display('_Footer.tpl.php');
?>
