<?php
	$this->assign('title','PHREEZEFB | Home');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?>

	<div class="container">
	
	<!-- FB-ROOT IS REQUIRED TO BE ON THE PAGE -->
	<div id="fb-root"></div>

		<!-- Main hero unit for a primary marketing message or call to action -->
		<div class="hero-unit">
			<h1>Phreeze Facebook Example</h1>
			<p>This is an automatically generated application with the addition of several files
			to enable Facebook integration.</p>
			
			<p>To use this example, you must set up a new application in the Facebook dev center
			and enter the app Id and Secret into Controller/AuthController.php.</p>
			
			<p>If everything is configured correctly you should see either a login button or 
			your facebook thumbnail right below this line...</p>
			
			<!-- FACEBOOK LOGIN BUTTON WILL BE REPLACED -->
			<p><div class="fb-login-button" data-show-faces="true" data-width="200" data-max-rows="1"></div></p>
		</div>

		

		<hr>

		<footer>
			<p>&copy; <?php echo date('Y'); ?> PHREEZEFB</p>
		</footer>

	</div> <!-- /container -->

	
<!-- THIS LOADS THE REQUIRED AUTH LIBRARIES FOR FACEBOOK INTEGRATION -->
<script type="text/javascript">
	$LAB
		.script("scripts/model.js").wait()
		.script("scripts/model.extend.js").wait()
		.script("scripts/app/auth.js").wait(function(){
				auth.facebookAppId = '<?php $this->eprint($this->facebookAppId); ?>';
			}
		)
		.script("scripts/app/facebook.js");
</script>

<?php
	$this->display('_Footer.tpl.php');
?>