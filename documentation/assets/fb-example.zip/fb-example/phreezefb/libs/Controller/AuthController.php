<?php
/** @package    FREEZEFB::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");
require_once("Model/User.php");
require_once("Model/Nonce.php");
require_once("verysimple/Phreeze/NotFoundException.php");

/**
 * Controller for dealing with authentication
 *
 * @package FREEZEFB::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class AuthController extends AppBaseController
{

	static $FACEBOOK_APP_ID = "";
	static $FACEBOOK_APP_SECRET = "";
	
	/**
	 * Override here for any controller-specific functionality
	 *
	 * @inheritdocs
	 */
	protected function Init()
	{
		parent::Init();
	}
	
	private function GetUserObject($user)
	{
		return $user;
	}
	
	
	public function Read()
	{
		$user = $this->GetCurrentUser();
		
		if ($user)
		{
			$this->RenderJSON($user, $this->JSONPCallback(), true, $this->SimpleObjectParams());
		}
		else
		{
			$var = new stdClass();
			$var->id = null;
			$this->RenderJSON($var, $this->JSONPCallback());
		}
			
		
	}
	

	/**
	 * API Method updates an existing campaign record and render response as JSON
	 */
	public function Update()
	{
		try
		{
			$json = json_decode(RequestUtil::GetBody());

			if (!$json)
			{
				throw new Exception('The request body does not contain valid JSON');
			}

			// we don't grab the user from the database, we get it from the session
			$pk = $this->GetRouter()->GetUrlParam('id');
			$user = $this->GetCurrentUser();
			
			// if this happens then it is possibly malicious behavior trying to update the wrong account
			if ($pk != $user->Id) throw new Exception('The id specified does not match your current session.  Please logout and login again.');

			// TODO: any fields that should not be updated by the user should be commented out

			// this is a primary key.  uncomment if updating is allowed
			// $user->Id = $this->SafeGetVal($json, 'id', $user->Id);

			$user->Status = $this->SafeGetVal($json, 'status', $user->Status);
			$user->Username = $this->SafeGetVal($json, 'username', $user->Username);
			// $user->FacebookId = $this->SafeGetVal($json, 'facebookId', $user->FacebookId); // no good reason to update this
			$user->FacebookUrl = $this->SafeGetVal($json, 'facebookUrl', $user->FacebookUrl);
			$user->Email = $this->SafeGetVal($json, 'email', $user->Email);
			$user->FirstName = $this->SafeGetVal($json, 'firstName', $user->FirstName);
			$user->LastName = $this->SafeGetVal($json, 'lastName', $user->LastName);
			$user->Gender = $this->SafeGetVal($json, 'gender', $user->Gender);
			$user->Locale = $this->SafeGetVal($json, 'locale', $user->Locale);
			$user->Timezone = $this->SafeGetVal($json, 'timezone', $user->Timezone);

			$user->Validate();
			$errors = $user->GetValidationErrors();

			if (count($errors) > 0)
			{
				$this->RenderErrorJSON('Please check the form for errors',$errors);
			}
			else
			{
				$user->Save();
				$this->RenderJSON($user, $this->JSONPCallback(), true, $this->SimpleObjectParams());
			}

			// since the user was updated we need to re-save them to the session
			$this->SetCurrentUser($user);
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}
	
	/**
	 * @TODO created a schedule task to run this function hourly and remove where this is
	 * called below in FacebookLogin()
	 * 
	 * This will delete all Nonces that are older than 24 hours from now.  We don't need to 
	 * keep an infinite amount of nonces in the table because we can check the signedRequest
	 * to see if was issued greater than 24 hours ago.  So we only need to keep 24 hours
	 * worth on Nonces.  This should be enough time to account for server clock differences
	 * but still now allow any signedRequests to be used more than once
	 */
	public function DeleteOldNonces()
	{
		$this->Phreezer->DataAdapter->Execute("delete from nonce where n_created_date < date_sub(now(), interval 24 hour)");
	}

	/**
	 *	Handles creating/logging an existing user in via facebook
	 */
	public function FacebookLogin()
	{
		$result = new stdClass();
		$result->userId = '';
		$result->isNew = false;
		$result->success = false;
		$result->message = '';
		
		$user = null;

		try
		{
			// this  will throw an exception if verification fails
			$facebookData = $this->VerifyFacebookSignature(
				RequestUtil::Get('signedRequest'), 
				self::$FACEBOOK_APP_SECRET
			);
			
			// this would probably be malicious behavior or the server clock being out of date
			if ($facebookData['issued_at'] < strtotime('-24 hours'))
				throw new Exception('The Facebook signedRequest is expired');
			
			// try to insert the nonce.  if this fails with a foreign key error then the
			// nonce is already in the database and so that means it has already been used
			try 
			{
				$nonce = new Nonce($this->Phreezer);
				$nonce->Code = $facebookData['code'];
				$nonce->CreatedDate = date('Y-m-d H:i:s');
				$nonce->Save();
			}
			catch (Exception $ex)
			{
				// this almost definitely indicates malicious behavior
				throw new Exception('The Facebook signedRequest has already been used');
			}
			
			// TODO: REMOVE THIS LINE AND SCHEDULE IT AS A TASK INSTEAD
			$this->DeleteOldNonces();
						
			try
			{
				$uc = new UserCriteria();
				$uc->FacebookId_Equals = $facebookData['user_id'];
				
				// this will throw a NotFoundException if the user doesn't exist
				$user = $this->Phreezer->GetByCriteria("User",$uc);
				
				$result->userId = $user->Id;
				$result->isNew = $user->Username == ''; // the username will be empty if the account is never updated
			}
			catch (NotFoundException $nfe)
			{
				// the user doesn't exist in the database, create a new one
				$user = new User($this->Phreezer);
				$user->FacebookId = $facebookData['user_id'];
				$user->Timezone = 0;
				$user->Save();

				$result->userId = $user->Id;
				$result->isNew = true;
			}
			
			// we either have an existing or new account, either way let's authenticate it
			$this->SetCurrentUser($user);
			
			$result->success = true;
			$result->message = 'OK';
		}
		catch (Exception $ex)
		{
			$result->message = $ex->getMessage();
		}

		$this->RenderJSON($result);
	}

	/**
	 * Facebook includes a url parameter 'signedRequest' with the request.  This contains
	 * an auth token and a signature of the token.  If the signature is correctly 
	 * signed using the app secret then the request can be trusted
	 * 
	 * @param string $signedRequest
	 * @param string $appSecret
	 * @return array
	 * @throws Exception
	 */
	private function VerifyFacebookSignature($signedRequest, $appSecret)
	{
		if (!$signedRequest) 
			throw new Exception("Facebook signature is missing");
		
		if (strpos($signedRequest,'.') === false)
			throw new Exception("Facebook signature is malformed");
		
		// request should be delimited with a period
		list($encodedSignature, $encodedData) = explode('.', $signedRequest, 2);

		$signature = $this->DecodeBase64URL($encodedSignature);
		$data = json_decode($this->DecodeBase64URL($encodedData), true);
		
		if (strtoupper($data['algorithm']) !== 'HMAC-SHA256') 
			throw new Exception('Facebook signature must be HMAC-SHA256');

		// this is the security part.  we use the app secret to generate a signature
		// for the encoded data and compare it to the signature from facebook
		$expectedSignature = hash_hmac('sha256', $encodedData, $appSecret, $raw = true);
		
		if ($signature !== $expectedSignature) 
			throw new Exception('Facebook signature verification failed');

		// if we made it this far then the signature was valid
		
		return $data;
	}

	/**
	 * Convenience function for decrypting a base64 url
	 * @param string $input
	 */
	private function DecodeBase64URL($input)
	{
		return base64_decode(strtr($input, '-_', '+/'));
	}


}
?>
