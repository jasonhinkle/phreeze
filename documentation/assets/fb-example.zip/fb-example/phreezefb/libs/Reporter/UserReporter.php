<?php
/** @package    PhreezeFb::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Reporter.php");

/**
 * This is an example Reporter based on the User object.  The reporter object
 * allows you to run arbitrary queries that return data which may or may not fith within
 * the data access API.  This can include aggregate data or subsets of data.
 *
 * Note that Reporters are read-only and cannot be used for saving data.
 *
 * @package PhreezeFb::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class UserReporter extends Reporter
{

	// the properties in this class must match the columns returned by GetCustomQuery().
	// 'CustomFieldExample' is an example that is not part of the `user` table
	public $CustomFieldExample;

	public $Id;
	public $Status;
	public $Username;
	public $FacebookId;
	public $FacebookUrl;
	public $Email;
	public $FirstName;
	public $LastName;
	public $Gender;
	public $Locale;
	public $Timezone;

	/*
	* GetCustomQuery returns a fully formed SQL statement.  The result columns
	* must match with the properties of this reporter object.
	*
	* @param Criteria $criteria
	* @return string SQL statement
	*/
	static function GetCustomQuery($criteria)
	{
		$sql = "select
			'custom value here...' as CustomFieldExample
			,`user`.`u_id` as Id
			,`user`.`u_status` as Status
			,`user`.`u_username` as Username
			,`user`.`u_facebook_id` as FacebookId
			,`user`.`u_facebook_url` as FacebookUrl
			,`user`.`u_email` as Email
			,`user`.`u_first_name` as FirstName
			,`user`.`u_last_name` as LastName
			,`user`.`u_gender` as Gender
			,`user`.`u_locale` as Locale
			,`user`.`u_timeZone` as Timezone
		from `user`";

		// the criteria can be used or you can write your own custom logic.
		// be sure to escape any user input with $criteria->Escape()
		$sql .= $criteria->GetWhere();
		$sql .= $criteria->GetOrder();

		return $sql;
	}
}

?>