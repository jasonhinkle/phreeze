<?php
/** @package    FreezeFb::Model */

/** import supporting libraries */
require_once("DAO/UserDAO.php");
require_once("UserCriteria.php");
require_once("verysimple/Authentication/IAuthenticatable.php");

/**
 * The User class extends UserDAO which provides the access
 * to the datastore.
 *
 * @package FreezeFb::Model
 * @author ClassBuilder
 * @version 1.0
 */
class User extends UserDAO implements IAuthenticatable
{

	/**
	 * Return true if the user is unknown
	 */
	public function IsAnonymous()
	{
		return $this->Id == '';
	}
	
	/**
	 * Currently this returns true for all authenticated users
	 * @param int $permission
	 */
	public function IsAuthorized($permission)
	{
		return !$this->IsAnonymous();
	}
	
	/**
	 * This is not currently implemented.  Facebook login is used instead
	 * @param string $username
	 * @param string $password
	 * @throws Exception
	 */
	public function Login($username,$password)
	{
		throw new Exception('Not implemented - Use Facebook login');
	}
	
	
	/**
	 * Override default validation
	 * @see Phreezable::Validate()
	 */
	public function Validate()
	{
		// example of custom validation
		// $this->ResetValidationErrors();
		// $errors = $this->GetValidationErrors();
		// if ($error == true) $this->AddValidationError('FieldName', 'Error Information');
		// return !$this->HasValidationErrors();

		return parent::Validate();
	}

	/**
	 * @see Phreezable::OnSave()
	 */
	public function OnSave($insert)
	{
		// the controller create/update methods validate before saving.  this will be a
		// redundant validation check, however it will ensure data integrity at the model
		// level based on validation rules.  comment this line out if this is not desired
		if (!$this->Validate()) throw new Exception('Unable to Save User: ' .  implode(', ', $this->GetValidationErrors()));

		// OnSave must return true or eles Phreeze will cancel the save operation
		return true;
	}

}

?>