<?php
/** @package    PhreezeFb::Model */

/** import supporting libraries */
require_once("DAO/NonceCriteriaDAO.php");

/**
 * The NonceCriteria class extends NonceDAOCriteria and is used
 * to query the database for objects and collections
 * 
 * @inheritdocs
 * @package PhreezeFb::Model
 * @author ClassBuilder
 * @version 1.0
 */
class NonceCriteria extends NonceCriteriaDAO
{
	
	/**
	 * For custom query logic, you may override OnProcess and set the $this->_where to whatever
	 * sql code is necessary.  If you choose to manually set _where then Phreeze will not touch
	 * your where clause at all and so any of the standard property names will be ignored
	 */
	/*
	function OnPrepare()
	{
		if ($this->MyCustomField == "special value")
		{
			// _where must begin with "where"
			$this->_where = "where db_field ....";
		}
	}
	*/

}
?>