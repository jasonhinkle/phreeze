<?php
/** @package    PhreezeFb::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");

/**
 * NonceMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the NonceDAO to the nonce datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package PhreezeFb::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class NonceMap implements IDaoMap
{
	/**
	 * Returns a singleton array of FieldMaps for the Nonce object
	 *
	 * @access public
	 * @return array of FieldMaps
	 */
	public static function GetFieldMaps()
	{
		static $fm = null;
		if ($fm == null)
		{
			$fm = Array();
			$fm["Id"] = new FieldMap("Id","nonce","n_id",true,FM_TYPE_BIGINT,20,null,true);
			$fm["Code"] = new FieldMap("Code","nonce","n_code",false,FM_TYPE_VARCHAR,250,null,false);
			$fm["CreatedDate"] = new FieldMap("CreatedDate","nonce","n_created_date",false,FM_TYPE_DATETIME,null,null,false);
		}
		return $fm;
	}

	/**
	 * Returns a singleton array of KeyMaps for the Nonce object
	 *
	 * @access public
	 * @return array of KeyMaps
	 */
	public static function GetKeyMaps()
	{
		static $km = null;
		if ($km == null)
		{
			$km = Array();
		}
		return $km;
	}

}

?>