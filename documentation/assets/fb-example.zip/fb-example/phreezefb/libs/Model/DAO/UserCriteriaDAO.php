<?php
/** @package    PhreezeFb::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * UserCriteria allows custom querying for the User object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package PhreezeFb::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class UserCriteriaDAO extends Criteria
{

	public $Id_Equals;
	public $Id_NotEquals;
	public $Id_IsLike;
	public $Id_IsNotLike;
	public $Id_BeginsWith;
	public $Id_EndWith;
	public $Id_GreaterThan;
	public $Id_GreaterThanOrEqual;
	public $Id_LessThan;
	public $Id_LessThanOrEqual;
	public $Id_In;
	public $Id_IsNotEmpty;
	public $Id_IsEmpty;
	public $Id_BitwiseOr;
	public $Id_BitwiseAnd;
	public $Status_Equals;
	public $Status_NotEquals;
	public $Status_IsLike;
	public $Status_IsNotLike;
	public $Status_BeginsWith;
	public $Status_EndWith;
	public $Status_GreaterThan;
	public $Status_GreaterThanOrEqual;
	public $Status_LessThan;
	public $Status_LessThanOrEqual;
	public $Status_In;
	public $Status_IsNotEmpty;
	public $Status_IsEmpty;
	public $Status_BitwiseOr;
	public $Status_BitwiseAnd;
	public $Username_Equals;
	public $Username_NotEquals;
	public $Username_IsLike;
	public $Username_IsNotLike;
	public $Username_BeginsWith;
	public $Username_EndWith;
	public $Username_GreaterThan;
	public $Username_GreaterThanOrEqual;
	public $Username_LessThan;
	public $Username_LessThanOrEqual;
	public $Username_In;
	public $Username_IsNotEmpty;
	public $Username_IsEmpty;
	public $Username_BitwiseOr;
	public $Username_BitwiseAnd;
	public $FacebookId_Equals;
	public $FacebookId_NotEquals;
	public $FacebookId_IsLike;
	public $FacebookId_IsNotLike;
	public $FacebookId_BeginsWith;
	public $FacebookId_EndWith;
	public $FacebookId_GreaterThan;
	public $FacebookId_GreaterThanOrEqual;
	public $FacebookId_LessThan;
	public $FacebookId_LessThanOrEqual;
	public $FacebookId_In;
	public $FacebookId_IsNotEmpty;
	public $FacebookId_IsEmpty;
	public $FacebookId_BitwiseOr;
	public $FacebookId_BitwiseAnd;
	public $FacebookUrl_Equals;
	public $FacebookUrl_NotEquals;
	public $FacebookUrl_IsLike;
	public $FacebookUrl_IsNotLike;
	public $FacebookUrl_BeginsWith;
	public $FacebookUrl_EndWith;
	public $FacebookUrl_GreaterThan;
	public $FacebookUrl_GreaterThanOrEqual;
	public $FacebookUrl_LessThan;
	public $FacebookUrl_LessThanOrEqual;
	public $FacebookUrl_In;
	public $FacebookUrl_IsNotEmpty;
	public $FacebookUrl_IsEmpty;
	public $FacebookUrl_BitwiseOr;
	public $FacebookUrl_BitwiseAnd;
	public $Email_Equals;
	public $Email_NotEquals;
	public $Email_IsLike;
	public $Email_IsNotLike;
	public $Email_BeginsWith;
	public $Email_EndWith;
	public $Email_GreaterThan;
	public $Email_GreaterThanOrEqual;
	public $Email_LessThan;
	public $Email_LessThanOrEqual;
	public $Email_In;
	public $Email_IsNotEmpty;
	public $Email_IsEmpty;
	public $Email_BitwiseOr;
	public $Email_BitwiseAnd;
	public $FirstName_Equals;
	public $FirstName_NotEquals;
	public $FirstName_IsLike;
	public $FirstName_IsNotLike;
	public $FirstName_BeginsWith;
	public $FirstName_EndWith;
	public $FirstName_GreaterThan;
	public $FirstName_GreaterThanOrEqual;
	public $FirstName_LessThan;
	public $FirstName_LessThanOrEqual;
	public $FirstName_In;
	public $FirstName_IsNotEmpty;
	public $FirstName_IsEmpty;
	public $FirstName_BitwiseOr;
	public $FirstName_BitwiseAnd;
	public $LastName_Equals;
	public $LastName_NotEquals;
	public $LastName_IsLike;
	public $LastName_IsNotLike;
	public $LastName_BeginsWith;
	public $LastName_EndWith;
	public $LastName_GreaterThan;
	public $LastName_GreaterThanOrEqual;
	public $LastName_LessThan;
	public $LastName_LessThanOrEqual;
	public $LastName_In;
	public $LastName_IsNotEmpty;
	public $LastName_IsEmpty;
	public $LastName_BitwiseOr;
	public $LastName_BitwiseAnd;
	public $Gender_Equals;
	public $Gender_NotEquals;
	public $Gender_IsLike;
	public $Gender_IsNotLike;
	public $Gender_BeginsWith;
	public $Gender_EndWith;
	public $Gender_GreaterThan;
	public $Gender_GreaterThanOrEqual;
	public $Gender_LessThan;
	public $Gender_LessThanOrEqual;
	public $Gender_In;
	public $Gender_IsNotEmpty;
	public $Gender_IsEmpty;
	public $Gender_BitwiseOr;
	public $Gender_BitwiseAnd;
	public $Locale_Equals;
	public $Locale_NotEquals;
	public $Locale_IsLike;
	public $Locale_IsNotLike;
	public $Locale_BeginsWith;
	public $Locale_EndWith;
	public $Locale_GreaterThan;
	public $Locale_GreaterThanOrEqual;
	public $Locale_LessThan;
	public $Locale_LessThanOrEqual;
	public $Locale_In;
	public $Locale_IsNotEmpty;
	public $Locale_IsEmpty;
	public $Locale_BitwiseOr;
	public $Locale_BitwiseAnd;
	public $Timezone_Equals;
	public $Timezone_NotEquals;
	public $Timezone_IsLike;
	public $Timezone_IsNotLike;
	public $Timezone_BeginsWith;
	public $Timezone_EndWith;
	public $Timezone_GreaterThan;
	public $Timezone_GreaterThanOrEqual;
	public $Timezone_LessThan;
	public $Timezone_LessThanOrEqual;
	public $Timezone_In;
	public $Timezone_IsNotEmpty;
	public $Timezone_IsEmpty;
	public $Timezone_BitwiseOr;
	public $Timezone_BitwiseAnd;

}

?>