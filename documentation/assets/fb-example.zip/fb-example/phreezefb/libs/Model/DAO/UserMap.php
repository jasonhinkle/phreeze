<?php
/** @package    PhreezeFb::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");

/**
 * UserMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the UserDAO to the user datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package PhreezeFb::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class UserMap implements IDaoMap
{
	/**
	 * Returns a singleton array of FieldMaps for the User object
	 *
	 * @access public
	 * @return array of FieldMaps
	 */
	public static function GetFieldMaps()
	{
		static $fm = null;
		if ($fm == null)
		{
			$fm = Array();
			$fm["Id"] = new FieldMap("Id","user","u_id",true,FM_TYPE_INT,10,null,true);
			$fm["Status"] = new FieldMap("Status","user","u_status",false,FM_TYPE_VARCHAR,10,"unverified",false);
			$fm["Username"] = new FieldMap("Username","user","u_username",false,FM_TYPE_VARCHAR,100,null,false);
			$fm["FacebookId"] = new FieldMap("FacebookId","user","u_facebook_id",false,FM_TYPE_VARCHAR,100,null,false);
			$fm["FacebookUrl"] = new FieldMap("FacebookUrl","user","u_facebook_url",false,FM_TYPE_VARCHAR,150,null,false);
			$fm["Email"] = new FieldMap("Email","user","u_email",false,FM_TYPE_VARCHAR,100,null,false);
			$fm["FirstName"] = new FieldMap("FirstName","user","u_first_name",false,FM_TYPE_VARCHAR,100,null,false);
			$fm["LastName"] = new FieldMap("LastName","user","u_last_name",false,FM_TYPE_VARCHAR,100,null,false);
			$fm["Gender"] = new FieldMap("Gender","user","u_gender",false,FM_TYPE_VARCHAR,15,null,false);
			$fm["Locale"] = new FieldMap("Locale","user","u_locale",false,FM_TYPE_VARCHAR,15,null,false);
			$fm["Timezone"] = new FieldMap("Timezone","user","u_timeZone",false,FM_TYPE_TINYINT,4,null,false);
		}
		return $fm;
	}

	/**
	 * Returns a singleton array of KeyMaps for the User object
	 *
	 * @access public
	 * @return array of KeyMaps
	 */
	public static function GetKeyMaps()
	{
		static $km = null;
		if ($km == null)
		{
			$km = Array();
		}
		return $km;
	}

}

?>