/**
 * facebook.js initializes authentication via facebook
 */

/**
 * facebook is a utility class with handlers for various
 * facebook api authentication events
 */
var facebook = {

	/**
	 * When an authentication change is received, if the user in not already
	 * logged in then issue a request to the facebook api to check login status
	 */
	onAuthResponseChange: function(authResponse) {
		
		if (auth.isLoggedIn()) {
			if (console) console.log('facebook.onAuthResponseChange user=' + auth.currentUser.get('username') + ' is already logged in');
		}
		else {	
			// TODO: do we care what the status is at this point..?
			var connected = authResponse.status == 'connected';		
			FB.getLoginStatus(facebook.onGetLoginStatus);
		}
	},
	
	/**
	 * This function will decode a facebook signed request and return the decoded response.
	 * WARNING: this does not validate the signature!  do not rely on for security
	 * @param string the facebook signedRequest parameter from a login status request
	 */
	decodeSignedRequest: function(signedRequest)
	{
		if (typeof Base64=='undefined') throw new Error('base64.js must be included');
		
		var parts = signedRequest.split('.');
		var encodedData = parts[1].replace(/-/g,'+').replace(/_/g,'/'); // replace special base64 'url' chars
		var jsonString = Base64.decode(encodedData).replace(/\0/g,""); // remove any trailing nulls
		
		return $.parseJSON(jsonString);
	},
	
	/**
	 * When the login status is returned from facebook, 
	 * if the status is connected then issue a call to
	 * facebook to get user's identity.  With the 
	 * identity information, make a call to the local
	 * auth controller to sign the user in.
	 * 
	 * The facebook signedRequest is passed through
	 * and verified
	 */
	onGetLoginStatus: function(loginResponse) {
		
		// TODO: if status is connected then login locally, otherwise logout locally
		var connected = loginResponse.status == 'connected';	
		
		// the client doesn't really need the information in the signedRequest because
		// it is just going to send it directly to the server which will handle
		// the decoding and validation.  but for reference - to decode on the client:
		// var authToken = facebook.decodeSignedRequest(loginResponse.authResponse.signedRequest);

		// pass the signed request through to local server for validation and authentication
		$.ajax({
			url: 'api/facebooklogin',
			dataType: 'json',
			data: {"signedRequest": loginResponse.authResponse.signedRequest},
			success: facebook.onLocalLoginResponse,
			error: function (jqXHR, textStatus, errorThrown) {
				if (textStatus == 'parsererror') {
					// TODO improve handling of server-side error
					alert(jqXHR.responseText);
				}
				else {
					// TODO: improve handling of communication error
					alert(errorThrown);
				}
				
			}
		});
		
	},
	
	/**
	 * On response from the local auth controller check to
	 * see if the login succeeded or failed and take the
	 * appropriate action
	 */
	onLocalLoginResponse: function(response) {
		
		if ( response.success ) {
			// login succeeded.
			
			if (response.isNew) {
				// this is a new account so we need populate it with personal details from facebook (name, etc)
				facebook.fetchFacebookProfile(response.userId, auth.updateCurrentUser);
			}
			else {
				// we've seen this user before so we can skip updating the account
				auth.fetchCurrentUser(response.userId);
			}

		}
		else {
			// TODO improve handler when login failuer error occurs
			alert(response.message);
		}
	},
	
	/**
	 * 
	 */
	fetchFacebookProfile: function(userId, responder)
	{
		// update the local account with account info if necessary
    	FB.api('/me',function(meResponse)
    	{
    		
    		var user = {
    			id: userId,
    			facebookId: meResponse.id,
    	    	firstName: meResponse.first_name,
    	    	gender: meResponse.gender,
    	    	email: meResponse.username+'@facebook.com',
    	    	lastName: meResponse.last_name,
    	    	facebookUrl: meResponse.link,
    	    	locale: meResponse.locale,
    	    	fullName: meResponse.name,
    	    	timezone: meResponse.timezone,
    	    	updatedTime: meResponse.updated_time,
    	    	username: meResponse.username,
    	    	verified: meResponse.verified
    		};

    		responder(user);

        });
	}
};


/**
 * fbAsyncInit is the entrypoint to the facebook API, called after initialization.
 * At this point we need to subscribe to the auth change event so that we can 
 * detect when a user has logged in or out
 */
window.fbAsyncInit = function() {
	
	if (auth.facebookAppId == '') 
	{
		alert('Please configure the Facebook app Id and Secret in Controller/AuthController.php');
		throw new Error('Facebook Id and Secret are not configured');
	}
	
	FB.init({
		appId: auth.facebookAppId, 
		channelUrl: 'channel.html',
		frictionlessRequests:true,
        status: true,
        cookie: true,
        xfbml: true  
    });

	// subscribe to the auth change event
	FB.Event.subscribe('auth.authResponseChange', facebook.onAuthResponseChange);
};

/** 
 * Load the facebook api asynchronously, parse the page looking for 
 * login button placeholders, and fire window.fbAsyncInit
 */
(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/all.js";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
