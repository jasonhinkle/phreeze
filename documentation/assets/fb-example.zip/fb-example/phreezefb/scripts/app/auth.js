/**
 * View logic for home
 */

/**
 * application logic specific to the home page
 */
var auth = {
	
	facebookAppId: '',
	currentUser: new model.CurrentUserModel(),
	
	isLoggedIn: function()
	{
		return auth.currentUser.get('id') != null;
	},
	
	/**
	 * Fetch the user via backbone and then fire onUserLoggedIn
	 */
	fetchCurrentUser: function(userId)
	{
		auth.currentUser.fetch({

			success: function() {
				auth.onLogin();
			},

			error: function(m, r) {
				// TODO improve error handling when user fetch fails
				alert(r.responseText);
			}

		});
	},
	

	/**
	 * 
	 */
	updateCurrentUser: function(attributes)
	{

		auth.currentUser.save({
			'id': attributes.id, // this will be verified by the server
			'username': attributes.username,
			'status': attributes.verified ? 'verified' : 'unverified',
			'email': attributes.email,
			'gender': attributes.gender,
			'firstName': attributes.firstName,
			'lastName': attributes.lastName,
			'facebookUrl': attributes.facebookUrl,
			'locale': attributes.locale,
			'timezone': attributes.timezone,
		}, {
			wait: true,
			success: function(){
				auth.onLogin();
		},
			error: function(model,response,scope){
				// TODO improve error handling when user fetch fails
				alert(response.responseText);
			}
		});

	},
	
	/**
	 * TODO: add custom logic to initialize the UI or do whatever is necessary once the user logs in
	 */
	onLogin: function()
	{
		if (console) console.log('auth.onLogin user ' + auth.currentUser.get('username') + ' is now logged in');
	}
}
