/**
 * backbone model definitions for PHREEZEFB
 */

/**
 * Use emulated HTTP if the server doesn't support PUT/DELETE or application/json requests
 */
Backbone.emulateHTTP = false;
Backbone.emulateJSON = false

var model = {};

/**
 * long polling duration in miliseconds.  (5000 = recommended, 0 = disabled)
 * warning: setting this to a low number will increase server load
 */
model.longPollDuration = 0;

/**
 * whether to refresh the collection immediately after a model is updated
 */
model.reloadCollectionOnModelUpdate = true;

/**
 * Nonce Backbone Model
 */
model.NonceModel = Backbone.Model.extend({
	urlRoot: 'api/nonce',
	idAttribute: 'id',
	id: '',
	code: '',
	createdDate: '',
	defaults: {
		'id': null,
		'code': '',
		'createdDate': new Date()
	}
});

/**
 * Nonce Backbone Collection
 */
model.NonceCollection = Backbone.Collection.extend({
	url: 'api/nonces',
	model: model.NonceModel,

	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	lastResponseText: null,
	collectionHasChanged: true,

	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, xhr) {

		this.collectionHasChanged = (this.lastResponseText != xhr.responseText);
		this.lastResponseText = xhr.responseText;

		var rows;

		if (response.currentPage)
		{
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
		}
		else
		{
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
		}

		return rows;
	}
});

/**
 * User Backbone Model
 */
model.UserModel = Backbone.Model.extend({
	urlRoot: 'api/user',
	idAttribute: 'id',
	id: '',
	status: '',
	username: '',
	facebookId: '',
	facebookUrl: '',
	email: '',
	firstName: '',
	lastName: '',
	gender: '',
	locale: '',
	timezone: '',
	defaults: {
		'id': null,
		'status': '',
		'username': '',
		'facebookId': '',
		'facebookUrl': '',
		'email': '',
		'firstName': '',
		'lastName': '',
		'gender': '',
		'locale': '',
		'timezone': ''
	}
});

/**
 * User Backbone Collection
 */
model.UserCollection = Backbone.Collection.extend({
	url: 'api/users',
	model: model.UserModel,

	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	lastResponseText: null,
	collectionHasChanged: true,

	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, xhr) {

		this.collectionHasChanged = (this.lastResponseText != xhr.responseText);
		this.lastResponseText = xhr.responseText;

		var rows;

		if (response.currentPage)
		{
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
		}
		else
		{
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
		}

		return rows;
	}
});

