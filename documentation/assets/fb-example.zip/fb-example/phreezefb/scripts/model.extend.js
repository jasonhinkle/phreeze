/**
 * model.extend.js is a place to extend the basic model classes without editing model.js
 * in case we need to re-generate the DAO files after a schema change
 */

model.CurrentUserModel = Backbone.Model.extend({
	urlRoot: 'api/currentuser',
	idAttribute: 'id',
	id: '',
	status: '',
	username: '',
	facebookId: '',
	facebookUrl: '',
	email: '',
	firstName: '',
	lastName: '',
	gender: '',
	locale: '',
	timezone: '',
	defaults: {
		'id': null,
		'status': '',
		'username': '',
		'facebookId': '',
		'facebookUrl': '',
		'email': '',
		'firstName': '',
		'lastName': '',
		'gender': '',
		'locale': '',
		'timezone': ''
	}
});
