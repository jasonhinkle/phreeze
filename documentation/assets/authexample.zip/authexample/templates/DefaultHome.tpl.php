<?php
	$this->assign('title','AUTHEXAMPLE | Home');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?>

	<div class="container">

		<!-- Main hero unit for a primary marketing message or call to action -->
		<div class="hero-unit">
			<h1><i class="icon-lock"></i> Authorization Example</h1>
			
			<h4>Be sure to run the included <a href="database.sql">SQL file</a> to install the database
			and configure your connection settings in _machine_config.php.</h4>
			
			<p>This is an example application with authentication that is pulled from a database of users.
			This is only one way of many that authentication can be implemented.  It is not required
			to construct your schema in the same way.</p>
			
			<p>This example demonstrates a middle-ground approach with role-based authentication that allows users to 
			be assigned a role, however with a fixed set of four permissions: Read, Write, Edit and Admin.  
			You can create as many roles as you like and define which of the four permissions each role has.
			These permission level names are completely arbitrary.  If they don't make sense with your app then you should
			re-name them to whatever makes sense for your particular application.</p>
			
			<p>If you don't need to configure permissions for roles on a dynamic basis then you may not even need
			a role table at all and you can just verify permissions based on a user role-type column.  If you 
			don't need to configure roles then this is a much simpler approach.  However if you require even more sophisticated 
			permissions then you can go the opposite direcdtion and implement a permission assignments and permissions-assignment tables 
			which are attached to roles.  Phreeze places no limitation on how simple or complex your authentication is.  
			The example here is just one approach.</p>
			
			<h2>What Should You Be Looking At?</h2>
			
			<p>If you try to view any data table views or the secure login example pages, you will notice that a certain permission level
			is required in order to access them.  Accessing them without logging in at all will trigger an error that you have not
			authenticated.  If you try to access an admin page with the "demo" account then the app will warn you that you do not 
			have sufficient permissions to access that page.</p>
			
			<p>Most of the authentication code is located in <strong>libs/Model/User.php</strong>.  If you look at the Login  
			and IsAuthorized methods you will see the mechanics of the permission system.</p>
			
			<h2>Password Hashing</h2>
			
			<p>This app also demonstrates how to do password hashing so that you do not save your passwords in plain text.
			This is implemented in <strong>libs/Model/User.php</strong> in the OnSave method and then is utilized again
			in the Login method.  This adds some complexitiy to the example which is not strictly necessary in order to
			demonstrate the authentication mechanics of Phreeze.  However since I imagine people may want to copy/paste
			from this example app I decided to implement hashing so that your code will be secure.</p>
			
			<p>There are some minor tweaks to the User controller that will leave the password un-touched if the user
			leaves the field blank.  Otherwise if a value is entered then the password will be changed.  None of this
			is required for authentication, however the code will probably be helpful to show you one way to implement
			password hashing.
			
		</div>


	</div> <!-- /container -->

<?php
	$this->display('_Footer.tpl.php');
?>