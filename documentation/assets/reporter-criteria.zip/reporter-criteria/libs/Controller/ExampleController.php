<?php
/** @package    CARGO::Example */

/** import supporting libraries */
require_once("AppBaseController.php");
require_once("Reporter/ExampleReporter.php");

/**

 */
class ExampleController extends AppBaseController
{

	/**
	 * An example method that uses a CriteriaFilter with a Reporter
	 */
	public function Query()
	{
		try
		{
			// using the criteria that was written for our example reporter
			$criteria = new ExampleReporterCriteria();
			
			// this is a hard-coded filter just for an example
			$cf = new CriteriaFilter('CustomerId,CustomerName,PackageDescription', '%jones%');
			$criteria->AddFilter($cf);

			$examples = $this->Phreezer->Query('ExampleReporter',$criteria);

			$this->RenderJSON($examples);
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

}

?>
