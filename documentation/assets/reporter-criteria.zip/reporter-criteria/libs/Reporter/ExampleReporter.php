<?php
/** @package    Cargo::Reporter */

/** import supporting libraries */
require_once("verysimple/Phreeze/Reporter.php");
require_once("ExampleReporterCriteria.php");

/**

 */
class ExampleReporter extends Reporter
{

	public $CustomerId;
	public $CustomerName;
	public $PackageDescription;

	/*
	* GetExampleQuery returns a fully formed SQL statement.  The result columns
	* must match with the properties of this reporter object.
	*
	* @param Criteria $criteria
	* @return string SQL statement
	*/
	static function GetCustomQuery($criteria)
	{
		$sql = "select
			`customer`.`c_id` as CustomerId
			,`customer`.`c_name` as CustomerName
			,`package`.`p_description` as PackageDescription

		from `customer` 
		inner join `package` on `package`.`p_customer_id` = `customer`.`c_id`";

		// the criteria can be used or you can write your own Example logic.
		// be sure to escape any user input with $criteria->Escape()
		$sql .= $criteria->GetWhere();
		$sql .= $criteria->GetOrder();

		return $sql;
	}
}

?>