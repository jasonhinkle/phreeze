<?php
/** @package	Cargo:Reporter */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**

 */
class ExampleReporterCriteria extends Criteria
{

	public function GetFieldFromProp($propname)
	{
		switch($propname)
		{
			case 'CustomerId':
				return 'c_id';
			case 'CustomerName':
				return 'c_name';
			case 'PackageDescription':
				return 'p_description';
			default:
				throw new Exception('Unable to locate the database column for the property: ' . $propname);
		}
	}

}

?>