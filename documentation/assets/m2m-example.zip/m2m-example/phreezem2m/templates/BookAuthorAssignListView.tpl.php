<?php
	$this->assign('title','Many To Many Example | BookAuthorAssigns');
	$this->assign('nav','bookauthorassigns');

	$this->display('_Header.tpl.php');
?>

<script type="text/javascript">
	$LAB.script("scripts/app/bookauthorassigns.js").wait(function(){
		page.init();
	});
</script>

<div class="container">

<h1>
	<i class="icon-th-list"></i> BookAuthorAssigns
	<span id=loader class="loader progress progress-striped active"><span class="bar"></span></span>
</h1>

	<!-- underscore template for the collection -->
	<script type="text/template" id="bookAuthorAssignCollectionTemplate">
		<table class="collection table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Book Id</th>
				<th>Author Id</th>
			</tr>
		</thead>
		<tbody>
		<% items.each(function(item) { %>
			<tr id="<%= _.escape(item.get('id')) %>">
				<td><%= _.escape(item.get('id') || '') %></td>
				<td><%= _.escape(item.get('bookId') || '') %></td>
				<td><%= _.escape(item.get('authorId') || '') %></td>
			</tr>
		<% }); %>
		</tbody>
		</table>

		<%=  view.getPaginationHtml(page) %>
	</script>

	<!-- underscore template for the model -->
	<script type="text/template" id="bookAuthorAssignModelTemplate">
		<form class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div id="idInputContainer" class="control-group">
					<label class="control-label" for="id">Id</label>
					<div class="controls inline-inputs">
						<span class="input-xlarge uneditable-input" id="id"><%= _.escape(item.get('id') || '') %></span>
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="bookIdInputContainer" class="control-group">
					<label class="control-label" for="bookId">Book Id</label>
					<div class="controls inline-inputs">
						<select id="bookId" name="bookId"></select>
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="authorIdInputContainer" class="control-group">
					<label class="control-label" for="authorId">Author Id</label>
					<div class="controls inline-inputs">
						<select id="authorId" name="authorId"></select>
						<span class="help-inline"></span>
					</div>
				</div>
			</fieldset>
		</form>

		<!-- delete button is is a separate form to prevent enter key from triggering a delete -->
		<form id="deleteBookAuthorAssignButtonContainer" class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div class="control-group">
					<label class="control-label"></label>
					<div class="controls">
						<button id="deleteBookAuthorAssignButton" class="btn btn-mini btn-danger"><i class="icon-trash icon-white"></i> Delete BookAuthorAssign</button>
						<span id="confirmDeleteBookAuthorAssignContainer" class="hide">
							<button id="cancelDeleteBookAuthorAssignButton" class="btn btn-mini">Cancel</button>
							<button id="confirmDeleteBookAuthorAssignButton" class="btn btn-mini btn-danger">Confirm</button>
						</span>
					</div>
				</div>
			</fieldset>
		</form>
	</script>

	<!-- modal edit dialog -->
	<div class="modal hide fade" id="bookAuthorAssignDetailDialog">
		<div class="modal-header">
			<a class="close" data-dismiss="modal">&times;</a>
			<h3>
				<i class="icon-edit"></i> Edit BookAuthorAssign
				<span id="modelLoader" class="loader progress progress-striped active"><span class="bar"></span></span>
			</h3>
		</div>
		<div class="modal-body">
			<div id="modelAlert"></div>
			<div id="bookAuthorAssignModelContainer"></div>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" >Cancel</button>
			<button id="saveBookAuthorAssignButton" class="btn btn-primary">Save Changes</button>
		</div>
	</div>

	<div id="collectionAlert"></div>

	<div id="bookAuthorAssignCollectionContainer" class="collectionContainer">
	</div>

	<p id="newButtonContainer" class="buttonContainer">
		<button id="newBookAuthorAssignButton" class="btn btn-primary">Add BookAuthorAssign</button>
	</p>

	<!-- footer -->
	<hr>

	<footer>
		<p>&copy; <?php echo date('Y'); ?> Many To Many Example</p>
	</footer>

</div> <!-- /container -->

<?php
	$this->display('_Footer.tpl.php');
?>
