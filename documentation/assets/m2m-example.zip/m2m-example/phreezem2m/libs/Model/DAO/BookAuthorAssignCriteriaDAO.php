<?php
/** @package    PhreezeM2m::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * BookAuthorAssignCriteria allows custom querying for the BookAuthorAssign object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package PhreezeM2m::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class BookAuthorAssignCriteriaDAO extends Criteria
{

	public $Id_Equals;
	public $Id_NotEquals;
	public $Id_IsLike;
	public $Id_IsNotLike;
	public $Id_BeginsWith;
	public $Id_EndWith;
	public $Id_GreaterThan;
	public $Id_GreaterThanOrEqual;
	public $Id_LessThan;
	public $Id_LessThanOrEqual;
	public $Id_In;
	public $Id_IsNotEmpty;
	public $Id_IsEmpty;
	public $Id_BitwiseOr;
	public $Id_BitwiseAnd;
	public $BookId_Equals;
	public $BookId_NotEquals;
	public $BookId_IsLike;
	public $BookId_IsNotLike;
	public $BookId_BeginsWith;
	public $BookId_EndWith;
	public $BookId_GreaterThan;
	public $BookId_GreaterThanOrEqual;
	public $BookId_LessThan;
	public $BookId_LessThanOrEqual;
	public $BookId_In;
	public $BookId_IsNotEmpty;
	public $BookId_IsEmpty;
	public $BookId_BitwiseOr;
	public $BookId_BitwiseAnd;
	public $AuthorId_Equals;
	public $AuthorId_NotEquals;
	public $AuthorId_IsLike;
	public $AuthorId_IsNotLike;
	public $AuthorId_BeginsWith;
	public $AuthorId_EndWith;
	public $AuthorId_GreaterThan;
	public $AuthorId_GreaterThanOrEqual;
	public $AuthorId_LessThan;
	public $AuthorId_LessThanOrEqual;
	public $AuthorId_In;
	public $AuthorId_IsNotEmpty;
	public $AuthorId_IsEmpty;
	public $AuthorId_BitwiseOr;
	public $AuthorId_BitwiseAnd;

}

?>