<?php
/** @package    PhreezeM2m::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");

/**
 * AuthorMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the AuthorDAO to the author datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package PhreezeM2m::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class AuthorMap implements IDaoMap
{
	/**
	 * Returns a singleton array of FieldMaps for the Author object
	 *
	 * @access public
	 * @return array of FieldMaps
	 */
	public static function GetFieldMaps()
	{
		static $fm = null;
		if ($fm == null)
		{
			$fm = Array();
			$fm["Id"] = new FieldMap("Id","author","a_id",true,FM_TYPE_INT,11,null,true);
			$fm["Name"] = new FieldMap("Name","author","a_name",false,FM_TYPE_VARCHAR,45,null,false);
		}
		return $fm;
	}

	/**
	 * Returns a singleton array of KeyMaps for the Author object
	 *
	 * @access public
	 * @return array of KeyMaps
	 */
	public static function GetKeyMaps()
	{
		static $km = null;
		if ($km == null)
		{
			$km = Array();
			$km["baa_author"] = new KeyMap("baa_author", "Id", "BookAuthorAssign", "AuthorId", KM_TYPE_ONETOMANY, KM_LOAD_LAZY);  // use KM_LOAD_EAGER with caution here (one-to-one relationships only)
		}
		return $km;
	}

}

?>