<?php
/** @package    PhreezeM2m::Model */

/** import supporting libraries */
require_once("DAO/BookDAO.php");
require_once("BookCriteria.php");

/**
 * The Book class extends BookDAO which provides the access
 * to the datastore.
 *
 * @package PhreezeM2m::Model
 * @author ClassBuilder
 * @version 1.0
 */
class Book extends BookDAO
{
	
	/**
	 * THIS METHOD HAS BEEN ADDED FOR EXAMPLE 2 TO DEMONSTRATE AN EFFICIENT WAY TO 
	 * OBTAIN THE MANY-TO-MANY RECORDS.  THIS WILL RETURN AN ARRAY OF AUTHORS
	 * ASSIGNED TO THIS BOOK
	 * @return array of zero or more Authors
	 */
	public function GetAuthors()
	{
		$authors = array();
		
		// using ToObjectArray will tell phreeze that you want all of the records so no need to do a count query
		$assignments = $this->GetBookAuthorAssigns()->ToObjectArray();
		
		foreach ($assignments as $assignment)
		{
			// this initiates another query (n+1) which is NOT scalable
			$authors[] = $assignment->GetAuthor();
		}
		
		return $authors;
	}
	
	
	/**
	 * THIS IS THE TRICK TO AVOIDING N+1 QUERIES.
	 * this line re-configures the key map for the assignment table, telling phreeze to
	 * do a join and bring in the author record along with each assignment
	 * KM_FETCH_INNER will do an inner join, KM_FETCH_EAGER will do a left join and KM_LAZY_LOAD will not do a join
	 */
	public function GetAuthorsEfficiently()
	{
		// This line of code is generated, but commented out at the bottom of _machine_config.php so you don't have to look up the key map name
		$this->_phreezer->SetLoadType("BookAuthorAssign","baa_author",KM_LOAD_EAGER); // KM_LOAD_INNER | KM_LOAD_EAGER | KM_LOAD_LAZY
		
		return $this->GetAuthors();
	}
	
	/**
	 * 
	 */
	public function GetAuthorsUsingReporter()
	{
		require_once 'Reporter/BookAuthorCriteria.php';
		
		$criteria = new BookAuthorCriteria();
		$criteria->BookId_Equals = $this->Id;
		
		// using ToObjectArray will tell phreeze that you want all of the records so no need to do a count query
		return $this->_phreezer->Query('BookAuthorReporter',$criteria)->ToObjectArray();
	}

	/**
	 * Override default validation
	 * @see Phreezable::Validate()
	 */
	public function Validate()
	{
		// example of custom validation
		// $this->ResetValidationErrors();
		// $errors = $this->GetValidationErrors();
		// if ($error == true) $this->AddValidationError('FieldName', 'Error Information');
		// return !$this->HasValidationErrors();

		return parent::Validate();
	}

	/**
	 * @see Phreezable::OnSave()
	 */
	public function OnSave($insert)
	{
		// the controller create/update methods validate before saving.  this will be a
		// redundant validation check, however it will ensure data integrity at the model
		// level based on validation rules.  comment this line out if this is not desired
		if (!$this->Validate()) throw new Exception('Unable to Save Book: ' .  implode(', ', $this->GetValidationErrors()));

		// OnSave must return true or eles Phreeze will cancel the save operation
		return true;
	}

}

?>