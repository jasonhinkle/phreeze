<?php
/** @package PhreezeM2m::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");
require_once('verysimple/Phreeze/ObserveToBrowser.php');

/**
 * @package PhreezeM2m::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class ExampleController extends AppBaseController
{

	/**
	 * Override here for any controller-specific functionality
	 */
	protected function Init()
	{
		parent::Init();

		// TODO: add controller-wide bootstrap code
	}

	/**
	 * Example 1 demonstrates the basics but has poor scalability
	 */
	public function Example1()
	{
		echo '<style>.debug, .query {font-family: courier new, courier; font-size: 9pt;} .query {color: blue;}</style>'
			. '<h1>Example 1</h1>'
			. '<p>This example demonstrates how the relationships work in phreeze, but will not scale because it '
			. 'creates an n+1 query (which is bad).  It\'s important to understand this first, though, '
			. 'before proceeding to the solution.</p>'
			. '<h4>Notice that we run: one query to get the book, another to get the assignments and then one query for each author (total of 5 queries, which would not scale if we have a lot of records)</h4>';
		
		
		// we want to debug the queries that are run so attach an observer to phreeze
		// this will echo debug information to the browser so you can see what queries are running
		$observer = new ObserveToBrowser();
		$this->Phreezer->AttachObserver($observer);
		
		// book with id of 3 has 3 authors assigned
		$book = $this->Phreezer->Get('Book',3);
		
		// LOOK AT THE SOURCE OF Book->GetAuthors TO SEE THE DEFAULT LAZY FETCHING
		$authors = $book->GetAuthors();
		
		foreach ($authors as $author)
		{
			// we aren't really doing anything here, just looping through
		}
		
	}

	/**
	 * Displayed when an invalid route is specified
	 */
	public function Example2()
	{
		echo '<style>.debug, .query {font-family: courier new, courier; font-size: 9pt;} .query {color: blue;}</style>'
			. '<h1>Example 2</h1>'
			. '<p>This example demonstrates how to retrieve many to many records in a more efficient way '
			. 'using eager fetching to create a sql joint statement.</p>'
			. '<h4>Notice that we only run two queries - this will not change regardless of how many records are returned</h4>';
		
		// we want to debug the queries that are run so attach an observer to phreeze
		// this will echo debug information to the browser so you can see what queries are running
		$observer = new ObserveToBrowser();
		$this->Phreezer->AttachObserver($observer);
		
		// book with id of 3 has 3 authors assigned
		$book = $this->Phreezer->Get('Book',3);
		
		// LOOK AT THE SOURCE OF Book->GetAuthorsEfficiently TO SEE EAGER FETCHING
		$authors = $book->GetAuthorsEfficiently();
		
		foreach ($authors as $author)
		{
			// we aren't really doing anything here, just looping through
		}
	}

	/**
	 * Display a fatal error message
	 */
	public function Example3()
	{
			echo '<style>.debug, .query {font-family: courier new, courier; font-size: 9pt;} .query {color: blue;}</style>'
			. '<h1>Example 3</h1>'
			. '<p>This example demonstrates how to retrieve many to many records using a Reporter object. '
			. 'This will generate the most efficient queries, but requires a little more work.</p>'
			. '<h4>Notice that we only run two queries - this will not change regardless of how many records are returned</h4>';
		
		// we want to debug the queries that are run so attach an observer to phreeze
		// this will echo debug information to the browser so you can see what queries are running
		$observer = new ObserveToBrowser();
		$this->Phreezer->AttachObserver($observer);
		
		// book with id of 3 has 3 authors assigned, this will run one query
		$book = $this->Phreezer->Get('Book',3);
		
		// LOOK AT THE SOURCE OF Book->GetAuthorsUsingReporter TO SEE HOW A CUSTOM REPORTER IS USED
		$authors = $book->GetAuthorsUsingReporter();
		
		foreach ($authors as $author)
		{
			// we aren't really doing anything here, just looping through
		}
	}

}
?>