<?php
/** @package    PhreezeM2m::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Reporter.php");

/**
 * This is an example Reporter based on the BookAuthorAssign object.  The reporter object
 * allows you to run arbitrary queries that return data which may or may not fith within
 * the data access API.  This can include aggregate data or subsets of data.
 *
 * Note that Reporters are read-only and cannot be used for saving data.
 *
 * @package PhreezeM2m::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class BookAuthorAssignReporter extends Reporter
{

	// the properties in this class must match the columns returned by GetCustomQuery().
	// 'CustomFieldExample' is an example that is not part of the `book_author_assign` table
	public $CustomFieldExample;

	public $Id;
	public $BookId;
	public $AuthorId;

	/*
	* GetCustomQuery returns a fully formed SQL statement.  The result columns
	* must match with the properties of this reporter object.
	*
	* @param Criteria $criteria
	* @return string SQL statement
	*/
	static function GetCustomQuery($criteria)
	{
		$sql = "select
			'custom value here...' as CustomFieldExample
			,`book_author_assign`.`baa_id` as Id
			,`book_author_assign`.`baa_book_id` as BookId
			,`book_author_assign`.`baa_author_id` as AuthorId
		from `book_author_assign`";

		// the criteria can be used or you can write your own custom logic.
		// be sure to escape any user input with $criteria->Escape()
		$sql .= $criteria->GetWhere();
		$sql .= $criteria->GetOrder();

		return $sql;
	}
}

?>