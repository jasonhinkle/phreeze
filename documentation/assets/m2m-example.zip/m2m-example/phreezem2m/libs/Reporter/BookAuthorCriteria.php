<?php
/** @package    PhreezeM2m::Model */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * The BookAuthorAssignCriteria class extends BookAuthorAssignDAOCriteria and is used
 * to query the database for objects and collections
 * 
 * @inheritdocs
 * @package PhreezeM2m::Model
 * @author ClassBuilder
 * @version 1.0
 */
class BookAuthorCriteria extends Criteria
{
	public $BookId_Equals;
	
	/**
	 * This is overridden so that we can instruct Phreezer what database field
	 * is referred to by the property "BookId"
	 * @see Criteria::GetFieldFromProp()
	 */
	protected function GetFieldFromProp($propname)
	{
		if ($propname == 'BookId') return 'baa_book_id';
		
		throw new Exception("Unknown Property '$propname' specified.");
	
	}
}
?>