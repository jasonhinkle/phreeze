<?php
/** @package    PhreezeM2m::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Reporter.php");

/**
 * This reporter does uses a join to get authors for a book
 *
 * Note that Reporters are read-only and cannot be used for saving data.
 *
 * @package PhreezeM2m::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class BookAuthorReporter extends Reporter
{

	// the properties in this class must match the columns returned by GetCustomQuery().
	// 'CustomFieldExample' is an example that is not part of the `author` table
	public $CustomFieldExample;

	public $Id;
	public $Name;

	/*
	* GetCustomQuery returns a fully formed SQL statement.  The result columns
	* must match with the properties of this reporter object.
	*
	* @param Criteria $criteria
	* @return string SQL statement
	*/
	static function GetCustomQuery($criteria)
	{
		if (!$criteria->BookId_Equals) throw new Exception('BookId_Equals is required');
		
		$sql = "select
			`author`.`a_id` as Id
			,`author`.`a_name` as Name
		from `author`
		inner join book_author_assign on baa_author_id = a_id
		where baa_book_id = '" . $criteria->Escape($criteria->BookId_Equals) . "'";
		
		$sql .= $criteria->GetOrder();

		return $sql;
	}
}

?>