<?php
/**
 * @package Many To Many Example
 *
 * APPLICATION-WIDE CONFIGURATION SETTINGS
 *
 * This file contains application-wide configuration settings.  The settings
 * here will be the same regardless of the machine on which the app is running.
 *
 * This configuration should be added to version control.
 *
 * No settings should be added to this file that would need to be changed
 * on a per-machine basic (ie local, staging or production).  Any
 * machine-specific settings should be added to _machine_config.php
 */

/**
 * APPLICATION ROOT DIRECTORY
 * If the application doesn't detect this correctly then it can be set explicitly
 */
GlobalConfig::$APP_ROOT = realpath("./");

/**
 * INCLUDE PATH
 * Adjust the include path as necessary so PHP can locate required libraries
 */
set_include_path(
		GlobalConfig::$APP_ROOT . '/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/libs/phreeze/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/../phreeze/libs' . PATH_SEPARATOR .
		get_include_path()
);

/**
 * RENDER ENGINE
 * You can use any template system that implements
 * IRenderEngine for the view layer.  Phreeze provides pre-built
 * implementations for Smarty, Savant and plain PHP.
 */
require_once 'verysimple/Phreeze/SavantRenderEngine.php';
GlobalConfig::$TEMPLATE_ENGINE = 'SavantRenderEngine';
GlobalConfig::$TEMPLATE_PATH = GlobalConfig::$APP_ROOT . '/templates/';

/**
 * ROUTE MAP
 * The route map connects URLs to Controller+Method and additionally maps the
 * wildcards to a named parameter so that they are accessible inside the
 * Controller without having to parse the URL for parameters such as IDs
 */
GlobalConfig::$ROUTE_MAP = array(

	'GET:example1' => array('route' => 'Example.Example1'),
	'GET:example2' => array('route' => 'Example.Example2'),
	'GET:example3' => array('route' => 'Example.Example3'),
		
	// default controller when no route specified
	'GET:' => array('route' => 'Default.Home'),
		
	// Author
	'GET:authors' => array('route' => 'Author.ListView'),
	'GET:author/(:num)' => array('route' => 'Author.SingleView', 'params' => array('id' => 1)),
	'GET:api/authors' => array('route' => 'Author.Query'),
	'POST:api/author' => array('route' => 'Author.Create'),
	'GET:api/author/(:num)' => array('route' => 'Author.Read', 'params' => array('id' => 2)),
	'PUT:api/author/(:num)' => array('route' => 'Author.Update', 'params' => array('id' => 2)),
	'DELETE:api/author/(:num)' => array('route' => 'Author.Delete', 'params' => array('id' => 2)),
		
	// Book
	'GET:books' => array('route' => 'Book.ListView'),
	'GET:book/(:num)' => array('route' => 'Book.SingleView', 'params' => array('id' => 1)),
	'GET:api/books' => array('route' => 'Book.Query'),
	'POST:api/book' => array('route' => 'Book.Create'),
	'GET:api/book/(:num)' => array('route' => 'Book.Read', 'params' => array('id' => 2)),
	'PUT:api/book/(:num)' => array('route' => 'Book.Update', 'params' => array('id' => 2)),
	'DELETE:api/book/(:num)' => array('route' => 'Book.Delete', 'params' => array('id' => 2)),
		
	// BookAuthorAssign
	'GET:bookauthorassigns' => array('route' => 'BookAuthorAssign.ListView'),
	'GET:bookauthorassign/(:num)' => array('route' => 'BookAuthorAssign.SingleView', 'params' => array('id' => 1)),
	'GET:api/bookauthorassigns' => array('route' => 'BookAuthorAssign.Query'),
	'POST:api/bookauthorassign' => array('route' => 'BookAuthorAssign.Create'),
	'GET:api/bookauthorassign/(:num)' => array('route' => 'BookAuthorAssign.Read', 'params' => array('id' => 2)),
	'PUT:api/bookauthorassign/(:num)' => array('route' => 'BookAuthorAssign.Update', 'params' => array('id' => 2)),
	'DELETE:api/bookauthorassign/(:num)' => array('route' => 'BookAuthorAssign.Delete', 'params' => array('id' => 2)),

	// catch any broken API urls
	'GET:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'PUT:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'POST:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'DELETE:api/(:any)' => array('route' => 'Default.ErrorApi404')
);

/**
 * FETCHING STRATEGY
 * You may uncomment any of the lines below to specify always eager fetching.
 * Alternatively, you can copy/paste to a specific page for one-time eager fetching
 * If you paste into a controller method, replace $G_PHREEZER with $this->Phreezer
 */
// $GlobalConfig->GetInstance()->GetPhreezer()->SetLoadType("BookAuthorAssign","baa_book",KM_LOAD_EAGER); // KM_LOAD_INNER | KM_LOAD_EAGER | KM_LOAD_LAZY
// $GlobalConfig->GetInstance()->GetPhreezer()->SetLoadType("BookAuthorAssign","baa_author",KM_LOAD_EAGER); // KM_LOAD_INNER | KM_LOAD_EAGER | KM_LOAD_LAZY
?>