/**
 * backbone model definitions for Many To Many Example
 */

/**
 * Use emulated HTTP if the server doesn't support PUT/DELETE or application/json requests
 */
Backbone.emulateHTTP = false;
Backbone.emulateJSON = false

var model = {};

/**
 * long polling duration in miliseconds.  (5000 = recommended, 0 = disabled)
 * warning: setting this to a low number will increase server load
 */
model.longPollDuration = 0;

/**
 * whether to refresh the collection immediately after a model is updated
 */
model.reloadCollectionOnModelUpdate = true;

/**
 * Author Backbone Model
 */
model.AuthorModel = Backbone.Model.extend({
	urlRoot: 'api/author',
	idAttribute: 'id',
	id: '',
	name: '',
	defaults: {
		'id': null,
		'name': ''
	}
});

/**
 * Author Backbone Collection
 */
model.AuthorCollection = Backbone.Collection.extend({
	url: 'api/authors',
	model: model.AuthorModel,

	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	lastResponseText: null,
	collectionHasChanged: true,

	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, xhr) {

		this.collectionHasChanged = (this.lastResponseText != xhr.responseText);
		this.lastResponseText = xhr.responseText;

		var rows;

		if (response.currentPage)
		{
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
		}
		else
		{
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
		}

		return rows;
	}
});

/**
 * Book Backbone Model
 */
model.BookModel = Backbone.Model.extend({
	urlRoot: 'api/book',
	idAttribute: 'id',
	id: '',
	name: '',
	defaults: {
		'id': null,
		'name': ''
	}
});

/**
 * Book Backbone Collection
 */
model.BookCollection = Backbone.Collection.extend({
	url: 'api/books',
	model: model.BookModel,

	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	lastResponseText: null,
	collectionHasChanged: true,

	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, xhr) {

		this.collectionHasChanged = (this.lastResponseText != xhr.responseText);
		this.lastResponseText = xhr.responseText;

		var rows;

		if (response.currentPage)
		{
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
		}
		else
		{
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
		}

		return rows;
	}
});

/**
 * BookAuthorAssign Backbone Model
 */
model.BookAuthorAssignModel = Backbone.Model.extend({
	urlRoot: 'api/bookauthorassign',
	idAttribute: 'id',
	id: '',
	bookId: '',
	authorId: '',
	defaults: {
		'id': null,
		'bookId': '',
		'authorId': ''
	}
});

/**
 * BookAuthorAssign Backbone Collection
 */
model.BookAuthorAssignCollection = Backbone.Collection.extend({
	url: 'api/bookauthorassigns',
	model: model.BookAuthorAssignModel,

	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	lastResponseText: null,
	collectionHasChanged: true,

	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, xhr) {

		this.collectionHasChanged = (this.lastResponseText != xhr.responseText);
		this.lastResponseText = xhr.responseText;

		var rows;

		if (response.currentPage)
		{
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
		}
		else
		{
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
		}

		return rows;
	}
});

